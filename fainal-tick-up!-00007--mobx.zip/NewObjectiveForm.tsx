import React from 'react';

const NewObjectiveForm: React.FC = () => {
    return null;
};

export default NewObjectiveForm;
