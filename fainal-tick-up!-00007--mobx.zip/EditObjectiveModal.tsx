import React from 'react';

const EditObjectiveModal: React.FC = () => {
    return null;
};

export default EditObjectiveModal;
