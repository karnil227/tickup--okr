import React from 'react';

const NewKeyResultForm: React.FC = () => {
    return null;
};

export default NewKeyResultForm;
