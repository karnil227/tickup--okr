import React from 'react';

const KeyResultRow: React.FC = () => {
    return null;
};

export default KeyResultRow;
