import React from 'react';

const CalendarView: React.FC = () => {
    return null;
};

export default CalendarView;
