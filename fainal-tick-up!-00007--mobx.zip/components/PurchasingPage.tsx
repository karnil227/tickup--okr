import React from 'react';

const PurchasingPage: React.FC = () => {
    return null;
};

export default PurchasingPage;
