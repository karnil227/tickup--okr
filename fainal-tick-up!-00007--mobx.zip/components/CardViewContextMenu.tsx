import React from 'react';

const CardViewContextMenu: React.FC = () => {
    return null;
};

export default CardViewContextMenu;
