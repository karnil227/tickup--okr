import React from 'react';

const PrerequisitesModal: React.FC = () => {
    return null;
};

export default PrerequisitesModal;
