import React from 'react';

const AddBoardModal: React.FC = () => {
    return null;
};

export default AddBoardModal;
