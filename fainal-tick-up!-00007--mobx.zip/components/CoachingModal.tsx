import React from 'react';

const CoachingModal: React.FC = () => {
    return null;
};

export default CoachingModal;
