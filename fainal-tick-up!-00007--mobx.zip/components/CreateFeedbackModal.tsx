import React from 'react';

const CreateFeedbackModal: React.FC = () => {
    return null;
};

export default CreateFeedbackModal;
