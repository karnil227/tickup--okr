import React from 'react';

const AdminPage: React.FC = () => {
    return null;
};

export default AdminPage;
