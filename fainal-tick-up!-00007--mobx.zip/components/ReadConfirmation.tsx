import React from 'react';

const ReadConfirmation: React.FC = () => {
    return null;
};

export default ReadConfirmation;
