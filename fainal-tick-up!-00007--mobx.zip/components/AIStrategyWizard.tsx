import React from 'react';

const AIStrategyWizard: React.FC = () => {
    return null;
};

export default AIStrategyWizard;
