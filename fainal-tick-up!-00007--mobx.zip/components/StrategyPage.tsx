import React from 'react';

const StrategyPage: React.FC = () => {
    return null;
};

export default StrategyPage;
