import React from 'react';

const KanbanPage: React.FC = () => {
    return null;
};

export default KanbanPage;
