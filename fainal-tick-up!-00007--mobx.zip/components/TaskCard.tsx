import React from 'react';

const TaskCard: React.FC = () => {
    return null;
};

export default TaskCard;
