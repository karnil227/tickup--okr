import React from 'react';

const TaskSidePanel: React.FC = () => {
    return null;
};

export default TaskSidePanel;
