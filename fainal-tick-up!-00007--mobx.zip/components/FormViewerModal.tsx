import React from 'react';

const FormViewerModal: React.FC = () => {
    return null;
};

export default FormViewerModal;
