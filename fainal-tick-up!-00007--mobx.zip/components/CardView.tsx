import React from 'react';

const CardView: React.FC = () => {
    return null;
};

export default CardView;
