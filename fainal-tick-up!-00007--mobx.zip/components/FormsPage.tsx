import React from 'react';

const FormsPage: React.FC = () => {
    return null;
};

export default FormsPage;
