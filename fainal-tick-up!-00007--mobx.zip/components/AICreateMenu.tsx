import React from 'react';

const AICreateMenu: React.FC = () => {
    return null;
};

export default AICreateMenu;
