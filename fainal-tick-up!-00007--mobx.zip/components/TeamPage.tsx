import React from 'react';

const TeamPage: React.FC = () => {
    return null;
};

export default TeamPage;
