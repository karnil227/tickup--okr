import React from 'react';

const TableView: React.FC = () => {
    return null;
};

export default TableView;
