import React from 'react';

const ProductionPage: React.FC = () => {
    return null;
};

export default ProductionPage;
