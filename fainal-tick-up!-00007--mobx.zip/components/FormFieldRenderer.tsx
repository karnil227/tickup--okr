import React from 'react';

const FormFieldRenderer: React.FC = () => {
    return null;
};

export default FormFieldRenderer;
