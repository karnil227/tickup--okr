import React from 'react';

const CreateFeedbackMenu: React.FC = () => {
    return null;
};

export default CreateFeedbackMenu;
