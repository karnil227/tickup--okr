import React from 'react';

const ArchivedBoardsModal: React.FC = () => {
    return null;
};

export default ArchivedBoardsModal;
