import React from 'react';

const DailyTargetCard: React.FC = () => {
    return null;
};

export default DailyTargetCard;
