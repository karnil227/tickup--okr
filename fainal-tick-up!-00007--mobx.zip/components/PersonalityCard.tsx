import React from 'react';

const PersonalityCard: React.FC = () => {
    return null;
};

export default PersonalityCard;
