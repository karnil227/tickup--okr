import React from 'react';

const DocumentEditor: React.FC = () => {
    return null;
};

export default DocumentEditor;
