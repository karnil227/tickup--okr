import React from 'react';

const InsightsPage: React.FC = () => {
    return null;
};

export default InsightsPage;
