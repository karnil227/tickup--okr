import React from 'react';

const AIProgramDesignerWizard: React.FC = () => {
    return null;
};

export default AIProgramDesignerWizard;
