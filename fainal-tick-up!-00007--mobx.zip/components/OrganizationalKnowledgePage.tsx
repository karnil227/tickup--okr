import React from 'react';

const OrganizationalKnowledgePage: React.FC = () => {
    return null;
};

export default OrganizationalKnowledgePage;
