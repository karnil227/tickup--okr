import React from 'react';

const OKRDisplayDashboard: React.FC = () => {
    return null;
};

export default OKRDisplayDashboard;
