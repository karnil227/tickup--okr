import React from 'react';

const CustomersPage: React.FC = () => {
    return null;
};

export default CustomersPage;
