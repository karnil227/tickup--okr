import React from 'react';

const FeedbackPage: React.FC = () => {
    return null;
};

export default FeedbackPage;
