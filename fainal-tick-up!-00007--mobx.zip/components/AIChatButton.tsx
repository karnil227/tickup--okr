import React from 'react';

const AIChatButton: React.FC = () => {
    return null;
};

export default AIChatButton;
