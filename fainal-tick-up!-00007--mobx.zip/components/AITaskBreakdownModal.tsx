import React from 'react';

const AITaskBreakdownModal: React.FC = () => {
    return null;
};

export default AITaskBreakdownModal;
