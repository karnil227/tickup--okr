import React from 'react';

const AnjamPage: React.FC = () => {
    return null;
};

export default AnjamPage;
