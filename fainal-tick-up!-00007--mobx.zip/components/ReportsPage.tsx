import React from 'react';

const ReportsPage: React.FC = () => {
    return null;
};

export default ReportsPage;
