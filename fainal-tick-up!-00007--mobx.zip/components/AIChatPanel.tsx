import React from 'react';

const AIChatPanel: React.FC = () => {
    return null;
};

export default AIChatPanel;
