import React from 'react';

const DocumentToolbar: React.FC = () => {
    return null;
};

export default DocumentToolbar;
