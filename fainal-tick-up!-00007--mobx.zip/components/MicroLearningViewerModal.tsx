import React from 'react';

const MicroLearningViewerModal: React.FC = () => {
    return null;
};

export default MicroLearningViewerModal;
