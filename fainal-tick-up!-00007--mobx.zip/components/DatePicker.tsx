import React from 'react';

const DatePicker: React.FC = () => {
    return null;
};

export default DatePicker;
