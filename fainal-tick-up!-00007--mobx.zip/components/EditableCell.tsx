import React from 'react';

const EditableCell: React.FC = () => {
    return null;
};

export default EditableCell;
