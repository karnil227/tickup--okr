import React from 'react';

const MemberProfileSidePanel: React.FC = () => {
    return null;
};

export default MemberProfileSidePanel;
