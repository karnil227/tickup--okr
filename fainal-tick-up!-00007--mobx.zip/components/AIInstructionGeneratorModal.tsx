import React from 'react';

const AIInstructionGeneratorModal: React.FC = () => {
    return null;
};

export default AIInstructionGeneratorModal;
