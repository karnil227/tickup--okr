import React from 'react';

const ObjectiveCard: React.FC = () => {
  return null;
};

export default ObjectiveCard;
