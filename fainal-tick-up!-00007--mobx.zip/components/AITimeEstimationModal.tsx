import React from 'react';

const AITimeEstimationModal: React.FC = () => {
    return null;
};

export default AITimeEstimationModal;
