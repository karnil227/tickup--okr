import React from 'react';

const DailySuccessRing: React.FC = () => {
    return null;
};

export default DailySuccessRing;
