import React from 'react';

const AISkillExtractorModal: React.FC = () => {
    return null;
};

export default AISkillExtractorModal;
