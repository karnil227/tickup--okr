import React from 'react';

const MarketingPage: React.FC = () => {
    return null;
};

export default MarketingPage;
