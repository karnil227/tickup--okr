import React from 'react';

const LearningResourceSelectorModal: React.FC = () => {
    return null;
};

export default LearningResourceSelectorModal;
