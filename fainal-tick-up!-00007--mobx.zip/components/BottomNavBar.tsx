import React from 'react';

const BottomNavBar: React.FC = () => {
    return null;
};

export default BottomNavBar;
