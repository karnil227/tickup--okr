import React from 'react';

const SlashCommandMenu: React.FC = () => {
    return null;
};

export default SlashCommandMenu;
