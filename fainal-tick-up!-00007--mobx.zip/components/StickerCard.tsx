import React from 'react';

const StickerCard: React.FC = () => {
    return null;
};

export default StickerCard;
