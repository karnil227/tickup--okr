import React from 'react';

export const ProcessView: React.FC = () => {
    return null;
};
