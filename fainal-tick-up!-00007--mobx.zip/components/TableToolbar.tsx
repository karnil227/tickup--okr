import React from 'react';

const TableActionMenu: React.FC = () => {
    return null;
};

export default TableActionMenu;
