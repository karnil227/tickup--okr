import React from 'react';

const ConsultantPopover: React.FC = () => {
    return null;
};

export default ConsultantPopover;
