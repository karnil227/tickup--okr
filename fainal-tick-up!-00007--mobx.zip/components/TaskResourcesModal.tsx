import React from 'react';

const TaskResourcesModal: React.FC = () => {
    return null;
};

export default TaskResourcesModal;
