import React from 'react';

const BarChart: React.FC = () => {
    return null;
};

export default BarChart;
