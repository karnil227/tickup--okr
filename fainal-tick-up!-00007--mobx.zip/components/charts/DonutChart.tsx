import React from 'react';

const DonutChart: React.FC = () => {
    return null;
};

export default DonutChart;
