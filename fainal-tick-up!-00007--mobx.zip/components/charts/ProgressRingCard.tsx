import React from 'react';

const ProgressRingCard: React.FC = () => {
    return null;
};

export default ProgressRingCard;
