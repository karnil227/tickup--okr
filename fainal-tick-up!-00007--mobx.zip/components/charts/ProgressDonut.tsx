import React from 'react';

const ProgressDonut: React.FC = () => {
    return null;
};

export default ProgressDonut;
