import React from 'react';

const TreemapChart: React.FC = () => {
    return null;
};

export default TreemapChart;
