import React from 'react';

const RadarChart: React.FC = () => {
    return null;
};

export default RadarChart;
