import React from 'react';

const PieChart: React.FC = () => {
    return null;
};

export default PieChart;
