import React from 'react';

const TrendLineChart: React.FC = () => {
    return null;
};

export default TrendLineChart;
