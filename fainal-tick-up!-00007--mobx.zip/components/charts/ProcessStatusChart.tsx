import React from 'react';

const ProcessStatusChart: React.FC = () => {
    return null;
};

export default ProcessStatusChart;
