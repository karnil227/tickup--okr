import React from 'react';

const CrmPage: React.FC = () => {
    return null;
};

export default CrmPage;
