import React from 'react';

const NewWorkspaceModal: React.FC = () => {
    return null;
};

export default NewWorkspaceModal;
