import React from 'react';

const FormBuilderModal: React.FC = () => {
    return null;
};

export default FormBuilderModal;
