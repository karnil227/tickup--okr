import React from 'react';

const ArchivedTasksModal: React.FC = () => {
    return null;
};

export default ArchivedTasksModal;
