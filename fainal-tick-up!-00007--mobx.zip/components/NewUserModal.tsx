import React from 'react';

const NewUserModal: React.FC = () => {
    return null;
};

export default NewUserModal;
