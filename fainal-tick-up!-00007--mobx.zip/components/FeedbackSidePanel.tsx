import React from 'react';

const FeedbackSidePanel: React.FC = () => {
    return null;
};

export default FeedbackSidePanel;
