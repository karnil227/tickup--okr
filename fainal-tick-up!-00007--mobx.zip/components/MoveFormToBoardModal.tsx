import React from 'react';

const MoveFormToBoardModal: React.FC = () => {
    return null;
};

export default MoveFormToBoardModal;
