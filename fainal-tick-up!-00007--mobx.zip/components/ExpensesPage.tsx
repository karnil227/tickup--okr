import React from 'react';

const ExpensesPage: React.FC = () => {
    return null;
};

export default ExpensesPage;
