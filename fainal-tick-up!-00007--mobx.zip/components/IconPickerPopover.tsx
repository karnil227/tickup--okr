import React from 'react';

const IconPickerPopover: React.FC = () => {
    return null;
};

export default IconPickerPopover;
