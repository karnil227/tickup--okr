import React from 'react';

const FormCard: React.FC = () => {
    return null;
};

export default FormCard;
