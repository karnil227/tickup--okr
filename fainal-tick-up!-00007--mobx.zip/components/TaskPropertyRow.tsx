import React from 'react';

const TaskPropertyRow: React.FC = () => {
    return null;
};

export default TaskPropertyRow;
