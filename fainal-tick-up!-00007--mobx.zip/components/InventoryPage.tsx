import React from 'react';

const InventoryPage: React.FC = () => {
    return null;
};

export default InventoryPage;
