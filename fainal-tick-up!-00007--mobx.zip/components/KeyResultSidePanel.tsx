import React from 'react';

const KeyResultSidePanel: React.FC<any> = () => {
  return null;
};

export default KeyResultSidePanel;
