import React from 'react';

const PersonalDevelopmentPage: React.FC = () => {
    return null;
};

export default PersonalDevelopmentPage;
