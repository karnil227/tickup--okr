import React from 'react';

const UpgradePage: React.FC = () => {
    return null;
};

export default UpgradePage;
