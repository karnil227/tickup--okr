import React from 'react';

const KrProgressBar: React.FC = () => {
    return null;
};

export default KrProgressBar;
