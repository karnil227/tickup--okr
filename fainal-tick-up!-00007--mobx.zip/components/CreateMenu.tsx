import React from 'react';

const CreateMenu: React.FC = () => {
    return null;
};

export default CreateMenu;
