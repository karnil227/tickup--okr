import React from 'react';

const AddProjectModal: React.FC = () => {
    return null;
};

export default AddProjectModal;
