import React from 'react';

const LearningPage: React.FC = () => {
    return null;
};

export default LearningPage;
