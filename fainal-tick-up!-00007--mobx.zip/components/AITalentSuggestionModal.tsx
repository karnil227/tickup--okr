import React from 'react';

const AITalentSuggestionModal: React.FC = () => {
    return null;
};

export default AITalentSuggestionModal;
