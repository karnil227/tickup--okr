import React from 'react';

const SkillsDisplay: React.FC = () => {
    return null;
};

export default SkillsDisplay;
