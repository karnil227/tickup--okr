import React from 'react';

const FormDisplay: React.FC = () => {
    return null;
};

export default FormDisplay;
