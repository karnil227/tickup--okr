import React from 'react';

const ManageSkillsModal: React.FC = () => {
    return null;
};

export default ManageSkillsModal;
