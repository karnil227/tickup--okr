import React from 'react';

const CreateStrategyMenu: React.FC = () => {
    return null;
};

export default CreateStrategyMenu;
