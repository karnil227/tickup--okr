import React from 'react';

const ManageFeedbackTagsModal: React.FC = () => {
    return null;
};

export default ManageFeedbackTagsModal;
