import React from 'react';

const CreateMicroLearningModal: React.FC = () => {
    return null;
};

export default CreateMicroLearningModal;
