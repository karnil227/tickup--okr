import React from 'react';

const ConsultingChatbot: React.FC = () => {
    return null;
};

export default ConsultingChatbot;
