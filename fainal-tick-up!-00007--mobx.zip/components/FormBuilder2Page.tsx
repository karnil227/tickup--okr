import React from 'react';

const FormBuilder2Page: React.FC = () => {
    return null;
};

export default FormBuilder2Page;
