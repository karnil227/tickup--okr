import React from 'react';

const AITaskGeneratorModal: React.FC = () => {
    return null;
};

export default AITaskGeneratorModal;
