import React from 'react';

const DailyTargetTaskCard: React.FC = () => {
    return null;
};

export default DailyTargetTaskCard;
