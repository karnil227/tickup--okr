import React from 'react';

const KanbanColumnComponent: React.FC = () => {
    return null;
};

export default KanbanColumnComponent;
