import React from 'react';

const RequiredSkillsModal: React.FC = () => {
    return null;
};

export default RequiredSkillsModal;
