import React from 'react';

const ArchivedProjectsModal: React.FC = () => {
    return null;
};

export default ArchivedProjectsModal;
