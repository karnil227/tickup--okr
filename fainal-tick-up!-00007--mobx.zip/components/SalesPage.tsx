import React from 'react';

const SalesPage: React.FC = () => {
    return null;
};

export default SalesPage;
