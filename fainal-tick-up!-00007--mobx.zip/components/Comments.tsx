import React from 'react';

const Comments: React.FC = () => {
    return null;
};

export default Comments;
