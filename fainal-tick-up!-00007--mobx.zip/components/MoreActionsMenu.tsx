import React from 'react';

const MoreActionsMenu: React.FC = () => {
    return null;
};

export default MoreActionsMenu;
