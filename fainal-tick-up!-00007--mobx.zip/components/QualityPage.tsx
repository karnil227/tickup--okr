import React from 'react';

const QualityPage: React.FC = () => {
    return null;
};

export default QualityPage;
