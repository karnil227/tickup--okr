import React from 'react';

const ProcessStepSidePanel: React.FC = () => {
    return null;
};

export default ProcessStepSidePanel;
