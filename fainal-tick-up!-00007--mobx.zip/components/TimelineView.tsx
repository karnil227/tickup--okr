import React from 'react';

export const TimelineView: React.FC = () => {
    return null;
};
