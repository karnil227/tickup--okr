import React from 'react';

const IkigaiWizard: React.FC = () => {
    return null;
};

export default IkigaiWizard;
