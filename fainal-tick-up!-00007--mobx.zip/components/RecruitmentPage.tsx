import React from 'react';

const RecruitmentPage: React.FC = () => {
    return null;
};

export default RecruitmentPage;
