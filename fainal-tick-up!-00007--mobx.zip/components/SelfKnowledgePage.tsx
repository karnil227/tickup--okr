import React from 'react';

const SelfKnowledgePage: React.FC = () => {
    return null;
};

export default SelfKnowledgePage;
