import React from 'react';

const UserProgressRow: React.FC = () => {
    return null;
};

export default UserProgressRow;
