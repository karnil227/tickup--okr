import React from 'react';

const MemberProfilePage: React.FC = () => {
    return null;
};

export default MemberProfilePage;
