import React from 'react';

const CustomizeNavModal: React.FC = () => {
    return null;
};

export default CustomizeNavModal;
