import React from 'react';

const ListView: React.FC = () => {
    return null;
};

export default ListView;
