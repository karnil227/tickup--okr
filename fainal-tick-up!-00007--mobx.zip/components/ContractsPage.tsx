import React from 'react';

const ContractsPage: React.FC = () => {
    return null;
};

export default ContractsPage;
