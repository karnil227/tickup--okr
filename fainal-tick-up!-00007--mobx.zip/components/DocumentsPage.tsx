import React from 'react';

const DocumentsPage: React.FC = () => {
    return null;
};

export default DocumentsPage;
