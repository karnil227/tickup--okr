import React from 'react';

const AddTaskModal: React.FC = () => {
    return null;
};

export default AddTaskModal;
