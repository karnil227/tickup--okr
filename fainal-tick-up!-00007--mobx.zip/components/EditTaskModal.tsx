import React from 'react';

const EditTaskModal: React.FC = () => {
    return null;
};

export default EditTaskModal;
