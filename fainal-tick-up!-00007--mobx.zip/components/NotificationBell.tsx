import React from 'react';

const NotificationBell: React.FC = () => {
    return null;
};

export default NotificationBell;
