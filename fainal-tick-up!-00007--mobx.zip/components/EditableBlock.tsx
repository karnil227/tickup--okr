import React from 'react';

const EditableBlock: React.FC = () => {
    return null;
};

export default EditableBlock;
