import React from 'react';

const NewTeamModal: React.FC = () => {
    return null;
};

export default NewTeamModal;
