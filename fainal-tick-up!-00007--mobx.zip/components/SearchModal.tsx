import React from 'react';

const SearchModal: React.FC = () => {
    return null;
};

export default SearchModal;
