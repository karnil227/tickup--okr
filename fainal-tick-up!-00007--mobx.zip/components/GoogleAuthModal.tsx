import React from 'react';

const GoogleAuthModal: React.FC = () => {
    return null;
};

export default GoogleAuthModal;
