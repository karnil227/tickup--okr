import React from 'react';

const AddKeyResultModal: React.FC = () => {
    return null;
};

export default AddKeyResultModal;